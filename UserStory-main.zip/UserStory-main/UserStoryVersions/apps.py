from django.apps import AppConfig


class UserstoryversionsConfig(AppConfig):
    name = 'UserStoryVersions'
