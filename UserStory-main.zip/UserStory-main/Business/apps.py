from django.apps import AppConfig


class BusinessConfig(AppConfig):
    name = 'Business'
