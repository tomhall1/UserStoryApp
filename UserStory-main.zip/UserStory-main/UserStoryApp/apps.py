from django.apps import AppConfig


class UserstoryappConfig(AppConfig):
    name = 'UserStoryApp'
