from django.apps import AppConfig


class UserstoriesConfig(AppConfig):
    name = 'UserStories'
